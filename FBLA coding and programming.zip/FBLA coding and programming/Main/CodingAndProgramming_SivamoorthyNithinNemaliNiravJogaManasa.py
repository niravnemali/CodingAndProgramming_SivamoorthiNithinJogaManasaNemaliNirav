from tkinter import Tk, Canvas, Button, PhotoImage, Entry, Text, Scrollbar
from tkinter import ttk
import tkinter as tk
import sqlite3
import os
from pathlib import Path


# Define SCRIPT_DIR at the beginning of your script
SCRIPT_DIR = Path(__file__).parent

def relative_to_assets(path: str) -> Path:
    return SCRIPT_DIR / "assets" / "frame0" / Path(path)



def search(event=None):
    search_term = entry_search_var.get()
    selected_type = type_filter_var.get()

    query = "SELECT * FROM CTE_Partners WHERE 1=1"

    if search_term:
        query += " AND ("
        for col in columns:
            query += f"{col} LIKE '%{search_term}%' OR "
        query = query[:-4] + ")"

    if selected_type:
        query += f" AND Type_of_Organization = '{selected_type}'"

    cursor.execute(query)
    result = cursor.fetchall()

    for row in tree.get_children():
        tree.delete(row)

    for row in result:
        # Exclude the ID column when inserting data into the Treeview
        tree.insert('', 'end', values=row[1:])


def open_main_page():
    welcome_frame.pack_forget()
    main_frame.pack(fill="both", expand=True)  # Use fill="both" and expand=True to fill the whole window

def open_info_page():
    main_frame.pack_forget()
    info_frame.pack(fill="both", expand=True)

def open_info_page_from_info():
    info_frame.pack_forget()
    main_frame.pack(fill="both", expand=True)

# Create the main window
window = Tk()

# Set the working directory to the script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

window.geometry("700x550")
window.title("Welcome to the Application")

# Welcome Page
welcome_frame = Canvas(window, bg="#FFFFFF", height=550, width=700, bd=0, highlightthickness=0, relief="ridge")
welcome_frame.pack(fill="both", expand=True)  # Fill the whole window

# Red header at the top
canvas_header_welcome = Canvas(
    welcome_frame,
    bg="#871C1C",
    height=80,
    width=700,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_header_welcome.pack(side="top", fill="x")  # Use pack to place it at the top and fill the width

canvas_header_welcome.create_text(
    350.0,
    40.0,  # Centered y coordinate
    anchor="center",
    text="Middleton Career and Technical Education Department",
    fill="#FFFFFF",
    font=("LilitaOne", 16)
)

# Welcome text
welcome_text = """Welcome to the CTE Community Partner Database! 

This application allows our school's CTE department to manage information on local businesses, organizations, and agency partners so that they can find industry partners that can provide the appropriate resources to maintain a successful CTE program. 

You can use the menu bar to:

- View all partners: See the full list of partners along with details like resources offered and contact information.

- Search partners: Filter the list by CTE category, organization type, or keywords to find relevant partners.

Please use this application as a centralized location to view and search partner information. Contact the CTE admin if you have any questions!
"""
canvas_welcome_text = Text(
    welcome_frame,
    bg="#FFFFFF",
    bd=0,
    wrap=tk.WORD,
    font=("Trocchi Regular", 10),
    state=tk.NORMAL
)
canvas_welcome_text.insert(tk.END, welcome_text)
canvas_welcome_text.pack(side="top", fill="both", expand=True)  # Use pack to fill the space and expand
scrollbar_welcome_text = Scrollbar(welcome_frame, command=canvas_welcome_text.yview)
scrollbar_welcome_text.pack(side=tk.RIGHT, fill=tk.Y)
canvas_welcome_text.config(yscrollcommand=scrollbar_welcome_text.set)
canvas_welcome_text.config(state=tk.DISABLED)

# Button to open the main page
button_image_start = PhotoImage(file=relative_to_assets("Enter_Program.png"))
button_start = Button(welcome_frame, image=button_image_start, borderwidth=0, highlightthickness=0, command=open_main_page, relief="flat")
button_start.pack(side="bottom", pady=(0, 10))  # Move the button all the way to the bottom

# Main Page
main_frame = Canvas(window, bg="#FFFFFF", bd=0, highlightthickness=0, relief="ridge")

# Create a new frame for the info page
info_frame = Canvas(window, bg="#FFFFFF", bd=0, highlightthickness=0, relief="ridge")

# Add text to the info frame
info_text = """Frequently Asked Questions

Q: How do I search for a partner?
A: You can search partners by using the search filters on the left side of the screen. Select the CTE category, organization type, or enter keywords to find matching partners. Click the "Search" button to view filtered results.

Q: How are partners organized? 
A: Partners are organized by CTE career category, with key details like organization type, contact information, and offered resources listed for each partner.

Q: One of my partner contacts changed their information. How do I update it?
A: Please contact the CTE database administrator to request any changes or updates to existing partner information. 

Q: I can't find my industry sector. Are there no partners for my programs?
A: First try filtering the “type of organization” to include your industry sector. If nothing shows up then it is likely that we have no partners in that sector. We are always looking to expand our partners across more career fields. Please speak to the CTE Director about getting connected with more industry partners relevant for your programs.

Still need help? Please contact the database administrator:

CTE Database Administrator
Email: cteadmin@hcps.net
Phone: 813-449-3223"""
canvas_info_text = Text(
    info_frame,
    bg="#FFFFFF",
    bd=0,
    wrap=tk.WORD,
    font=("Trocchi Regular", 12),
    state=tk.NORMAL
)
canvas_info_text.insert(tk.END, info_text)
canvas_info_text.pack(side="top", fill="both", expand=True)  # Use pack to fill the space and expand
scrollbar_info_text = Scrollbar(info_frame, command=canvas_info_text.yview)
scrollbar_info_text.pack(side=tk.RIGHT, fill=tk.Y)
canvas_info_text.config(yscrollcommand=scrollbar_info_text.set)
canvas_info_text.config(state=tk.DISABLED)


# Red header with the names
canvas_header_main = Canvas(
    main_frame,
    bg="#861B1B",
    height=80,
    width=700,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_header_main.pack(side="top", fill="x")  # Use pack to place it at the top and fill the width

canvas_header_main.create_text(
    350.0,
    40.0,  # Centered y coordinate
    anchor="center",
    text="Middleton",
    fill="#FFFFFF",
    font=("LilitaOne", 24)
)

canvas_header_main.create_text(
    350.0,
    65.0,  # Centered y coordinate
    anchor="center",
    text="Career and Technical Education Department",
    fill="#FFFFFF",
    font=("LilitaOne", 16)
)

# Rest of the content
canvas_content_main = Canvas(
    main_frame,
    bg="#FFFFFF",
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_content_main.pack(side="top", fill="both", expand=True)  # Use pack to fill the space and expand

# Small title above the search bar
canvas_content_main.create_text(
    350.0,
    30.0,  # Adjusted y coordinate
    anchor="center",
    text="Search for Business Partners",
    fill="#921F1F",
    font=("Trocchi Regular", 14)
)

# Filter button and dropdown
type_filter_var = tk.StringVar()
type_filter_label = ttk.Label(canvas_content_main, text="Filter by Type of Organization:")
type_filter_label.place(x=10, y=80)  # Adjusted x and y coordinates
type_filter_dropdown = ttk.Combobox(canvas_content_main, textvariable=type_filter_var, values=["Medical", "Barbering", "Agriculture", "Engineering", "Information Technology","Computer Science", "Law", "Cullinary",])  # Add your organization types
type_filter_dropdown.place(x=180, y=80)  # Adjusted x and y coordinates

# Entry for search
entry_search_var = tk.StringVar()
entry_search = Entry(
    canvas_content_main,
    bd=0,
    bg="#C08080",
    fg="#000716",
    highlightthickness=0,
    textvariable=entry_search_var
)
entry_search.place(
    x=160.5,
    y=120.0,  # Adjusted y coordinate
    width=380.0,
    height=42.0
)

# Bind the Enter key to the search function
entry_search.bind("<Return>", search)

# Search button
button_image_search = PhotoImage(
    file=relative_to_assets("button_search.png"))
button_search = Button(
    canvas_content_main,
    image=button_image_search,
    borderwidth=0,
    highlightthickness=0,
    command=search,
    relief="flat"
)
button_search.place(
    x=560.0,
    y=120.0  # Adjusted y coordinate
)

# Button to go back to the main page
button_image_back = PhotoImage(file=relative_to_assets("Back_Button.png"))
button_back = Button(info_frame, image=button_image_back, borderwidth=0, highlightthickness=0, command=open_info_page_from_info, relief="flat")
button_back.pack(side="bottom", pady=(0, 10))  # Move the button all the way to the bottom

# Treeview to display data
columns = ('Organization_Name', 'Type_of_Organization', 'Resources_Available', 'Phone_Number')  # Updated column names
tree = ttk.Treeview(canvas_content_main, columns=columns, show='headings')

# Configure column headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=150)  # Adjust the width as needed

tree.pack(pady=180)  # Adjusted y coordinate

# Button below the table with Qicon.png
qicon_image = PhotoImage(file=relative_to_assets("Qicon.png"))
button_below_table = Button(
    canvas_content_main,
    image=qicon_image,
    command=open_info_page
)
button_below_table.place(x=50, y=400)  # Adjusted x and y coordinates


# Connect to SQLite database with error handling
try:
    # Connect to SQLite database
    conn = sqlite3.connect('CTE Partners.db') 
    cursor = conn.cursor()

    # Fetch data from the database
    cursor.execute("SELECT Organization_Name, Type_of_Organization, Resources_Available, Phone_Number FROM CTE_Partners")
    result = cursor.fetchall()

    # Clear existing data in the Treeview
    for row in tree.get_children():
        tree.delete(row)

    # Insert data into the Treeview excluding the ID column
    for row in result:
        tree.insert('', 'end', values=row[1:])

except sqlite3.Error as e:
    print(f"Error connecting to SQLite database: {e}")

# No need to close the database connection here

window.resizable(False, False)
window.mainloop()