from tkinter import Tk, Canvas, Button, PhotoImage, Entry, Text, Scrollbar
from tkinter import ttk
import tkinter as tk
import sqlite3
import os
from tkinter import simpledialog
from pathlib import Path
import time
import shutil

# Define constants
ASSETS_DIR = Path(__file__).parent / "assets" / "frame0"
DATABASE_FILE = 'CTE Partners.db'
WINDOW_WIDTH = 700
WINDOW_HEIGHT = 550
HEADER_COLOR = "#871C1C"
TEXT_COLOR = "#FFFFFF"
BUTTON_COLOR = "#C08080"
BUTTON_TEXT_COLOR = "#000716"
SCROLLBAR_COLOR = "#FFFFFF"
TEXT_FONT = ("Trocchi Regular", 10)
HEADER_FONT = ("LilitaOne", 16)
BUTTON_FONT = ("Trocchi Regular", 12)
HEADER_TEXT = "Middleton Career and Technical Education Department"
WELCOME_TEXT = """
Welcome to the CTE Community Partner Database! 

This application allows our school's CTE department to manage information on local businesses, organizations, and agency partners so that they can find industry partners that can provide the appropriate resources to maintain a successful CTE program. 

You can use the menu bar to:

- View all partners: See the full list of partners along with details like resources offered and contact information.

- Search partners: Filter the list by CTE category, organization type, or keywords to find relevant partners.

Please use this application as a centralized location to view and search partner information. Contact the CTE admin if you have any questions!
"""

# Define functions
def open_main_page():
    welcome_frame.pack_forget()
    main_frame.pack(fill="both", expand=True)  

def open_info_page():
    main_frame.pack_forget()
    info_frame.pack(fill="both", expand=True)

def open_info_page_from_info():
    info_frame.pack_forget()
    main_frame.pack(fill="both", expand=True)

def relative_to_assets(path: str) -> Path:
    return ASSETS_DIR / Path(path)

# Define a function to validate the search term
def is_valid_search_term(search_term):
    # Perform syntactical validation
    if not search_term:
        return False

    # Additional syntactical or semantic checks can be added here
    
    return True

# Define a function to validate the selected type
def is_valid_selected_type(selected_type):
    # Perform semantic validation
    valid_types = ["Medical", "Barbering", "Agriculture", "Engineering", "Information Technology", "Computer Science", "Law", "Cullinary", "None"]
    if selected_type not in valid_types:
        return False

    return True

# Define the search function with input validation
def search(event=None):
    # Retrieve search term and selected type from entry and dropdown
    search_term = entry_search_var.get()
    selected_type = type_filter_var.get()

    # Validate search term and selected type
    if not is_valid_search_term(search_term):
        # Display error message or handle invalid input
        print("Invalid search term.")
        return

    if not is_valid_selected_type(selected_type):
        # Display error message or handle invalid input
        print("Invalid selected type.")
        return

    # Build SQL query based on user input
    query = "SELECT * FROM CTE_Partners WHERE 1=1"
    query += f" AND (Organization_Name LIKE '%{search_term}%' OR Type_of_Organization LIKE '%{search_term}%' OR Resources_Available LIKE '%{search_term}%' OR Phone_Number LIKE '%{search_term}%')"

    if selected_type != "None":  
        query += f" AND Type_of_Organization = '{selected_type}'"

    # Execute the query and update the Treeview
    cursor.execute(query)
    result = cursor.fetchall()

    # Clear existing data in the Treeview
    for row in tree.get_children():
        tree.delete(row)

    # Insert filtered data into the Treeview excluding the ID column
    for row in result:
        tree.insert('', 'end', values=row[1:])

# Create the main window
window = Tk()

# Set the working directory to the script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Sets the size and title of the welcome page
window.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
window.title("Welcome to the Application")

# Welcome Page
welcome_frame = Canvas(window, bg="#FFFFFF", height=WINDOW_HEIGHT, width=WINDOW_WIDTH, bd=0, highlightthickness=0, relief="ridge")
welcome_frame.pack(fill="both", expand=True)  # Fill the whole window

# Creation of the read header that is at the top
canvas_header_welcome = Canvas(
    welcome_frame,
    bg=HEADER_COLOR,
    height=80,
    width=WINDOW_WIDTH,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_header_welcome.pack(side="top", fill="x")  # Used pack to fill the width completely and place this at the top

canvas_header_welcome.create_text(
    WINDOW_WIDTH / 2,
    40.0,  # Centered y coordinate
    anchor="center",
    text=HEADER_TEXT,
    fill=TEXT_COLOR,
    font=HEADER_FONT
)

# Welcome text
canvas_welcome_text = Text(
    welcome_frame,
    bg="#FFFFFF",
    bd=0,
    wrap=tk.WORD,
    font=TEXT_FONT,
    state=tk.NORMAL
)
canvas_welcome_text.insert(tk.END, WELCOME_TEXT)
canvas_welcome_text.pack(side="top", fill="both", expand=True)  # Use pack again to fill the space and expand

scrollbar_welcome_text = Scrollbar(welcome_frame, command=canvas_welcome_text.yview)
scrollbar_welcome_text.pack(side=tk.RIGHT, fill=tk.Y)
canvas_welcome_text.config(yscrollcommand=scrollbar_welcome_text.set)
canvas_welcome_text.config(state=tk.DISABLED)

# Creation of button to open the main page
button_image_start = PhotoImage(file=relative_to_assets("Enter_Program.png"))
button_start = Button(welcome_frame, image=button_image_start, borderwidth=0, highlightthickness=0, command=open_main_page, relief="flat")
button_start.pack(side="bottom", pady=(0, 10))  # Move the button all the way to the bottom

# Main Page
main_frame = Canvas(window, bg="#FFFFFF", bd=0, highlightthickness=0, relief="ridge")

# Create a new frame for the Q and A page
info_frame = Canvas(window, bg="#FFFFFF", bd=0, highlightthickness=0, relief="ridge")

# Add text to the Q and A frame
info_text = """
Frequently Asked Questions

Q: How do I search for a partner?
A: You can search partners by using the search filters on the left side of the screen. Select the CTE category, organization type, or enter keywords to find matching partners. Click the "Search" button to view filtered results.

Q: How are partners organized? 
A: Partners are organized by CTE career category, with key details like organization type, contact information, and offered resources listed for each partner.

Q: One of my partner contacts changed their information. How do I update it?
A: Please contact the CTE database administrator to request any changes or updates to existing partner information. 

Q: I can't find my industry sector. Are there no partners for my programs?
A: First try filtering the “type of organization” to include your industry sector. If nothing shows up then it is likely that we have no partners in that sector. We are always looking to expand our partners across more career fields. Please speak to the CTE Director about getting connected with more industry partners relevant for your programs.

Still need help? Please contact the database administrator:

CTE Database Administrator
Email: cteadmin@hcps.net
Phone: 813-449-3223
"""
canvas_info_text = Text(
    info_frame,
    bg="#FFFFFF",
    bd=0,
    wrap=tk.WORD,
    font=TEXT_FONT,
    state=tk.NORMAL
)
canvas_info_text.insert(tk.END, info_text)
canvas_info_text.pack(side="top", fill="both", expand=True) 
scrollbar_info_text = Scrollbar(info_frame, command=canvas_info_text.yview)
scrollbar_info_text.pack(side=tk.RIGHT, fill=tk.Y)
canvas_info_text.config(yscrollcommand=scrollbar_info_text.set)
canvas_info_text.config(state=tk.DISABLED)


# Red header with the names
canvas_header_main = Canvas(
    main_frame,
    bg=HEADER_COLOR,
    height=80,
    width=WINDOW_WIDTH,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_header_main.pack(side="top", fill="x")  

canvas_header_main.create_text(
    WINDOW_WIDTH / 2,
    40.0,  
    anchor="center",
    text="Middleton",
    fill=TEXT_COLOR,
    font=("LilitaOne", 24)
)

canvas_header_main.create_text(
    WINDOW_WIDTH / 2,
    65.0,  
    anchor="center",
    text="Career and Technical Education Department",
    fill=TEXT_COLOR,
    font=("LilitaOne", 16)
)

# Rest of the content
canvas_content_main = Canvas(
    main_frame,
    bg="#FFFFFF",
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas_content_main.pack(side="top", fill="both", expand=True)  

#  Creation of Small title above the search bar
canvas_content_main.create_text(
    WINDOW_WIDTH / 2,
    30.0,  
    anchor="center",
    text="Search for Business Partners",
    fill="#921F1F",
    font=("Trocchi Regular", 14)
)

# Filter button and dropdown
type_filter_var = tk.StringVar()
type_filter_label = ttk.Label(canvas_content_main, text="Filter by Type of Organization:")
type_filter_label.place(x=10, y=80)  # Adjusted x and y coordinates
type_filter_dropdown = ttk.Combobox(canvas_content_main, textvariable=type_filter_var, values=["Medical", "Barbering", "Agriculture", "Engineering", "Information Technology","Computer Science", "Law", "Cullinary","None"])  # Add your organization types
type_filter_dropdown.place(x=180, y=80)  # Adjusted x and y coordinates

# Entry for search
entry_search_var = tk.StringVar()
entry_search = Entry(
    canvas_content_main,
    bd=0,
    bg=BUTTON_COLOR,
    fg=BUTTON_TEXT_COLOR,
    highlightthickness=0,
    textvariable=entry_search_var
)
entry_search.place(
    x=160.5,
    y=120.0,  
    width=380.0,
    height=42.0
)

# Binded the Enter key to the search function
entry_search.bind("<Return>", search)

# Creation of Search button
button_image_search = PhotoImage(
    file=relative_to_assets("button_search.png"))
button_search = Button(
    canvas_content_main,
    image=button_image_search,
    borderwidth=0,
    highlightthickness=0,
    command=search,
    relief="flat"
)
button_search.place(
    x=560.0,
    y=120.0  
)

# Button to go back to the main page
button_image_back = PhotoImage(file=relative_to_assets("Back_Button.png"))
button_back = Button(info_frame, image=button_image_back, borderwidth=0, highlightthickness=0, command=open_info_page_from_info, relief="flat")
button_back.pack(side="bottom", pady=(0, 10))  # Move the button all the way to the bottom

# Treeview to display data
columns = ('Organization_Name', 'Type_of_Organization', 'Resources_Available', 'Phone_Number')  # Updated column names
tree = ttk.Treeview(canvas_content_main, columns=columns, show='headings')

# Configure column headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=150)  

tree.pack(pady=180)  

# Create text above the Q&A button
canvas_content_main.create_text(
    120.0,
    360.0,  # Adjust the y-coordinate as per your layout
    anchor="center",
    text="Click here for Q & A",
    fill="#921F1F",  # Adjust the color as needed
    font=("Trocchi Regular", 12)
)

# Q and A button created 
qicon_image = PhotoImage(file=relative_to_assets("Qicon.png"))
button_below_table = Button(
    canvas_content_main,
    image=qicon_image,
    command=open_info_page
)
button_below_table.place(x=100, y=400)  


# Connect to SQLite database with error handling
try:
    # Connect to SQLite database
    conn = sqlite3.connect(DATABASE_FILE) 
    cursor = conn.cursor()

    # Fetch data from the database
    cursor.execute("SELECT Organization_Name, Type_of_Organization, Resources_Available, Phone_Number FROM CTE_Partners")
    result = cursor.fetchall()

    # Clear existing data in the Treeview
    for row in tree.get_children():
        tree.delete(row)

    # Insert data into the Treeview with the correct order of columns
    for row in result:
        tree.insert('', 'end', values=row)

except sqlite3.Error as e:
    print(f"Error connecting to SQLite database: {e}")

window.resizable(False, False)
window.mainloop()